var isMobile = navigator.userAgent.match(/Android/i) || navigator.userAgent.match(/webOS/i) || navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i) || navigator.userAgent.match(/iPod/i) || navigator.userAgent.match(/BlackBerry/i) || navigator.userAgent.match(/Windows Phone/i);

function openWA() {
	var phoneNumber = " 917738497219",
		content = "Hi, I am interested to know more about the Lodha Adrina project in WORLI. Please contact me at the earliest.";
	link = "";
	if (isMobile) {
		link = "https://wa.me/" + phoneNumber + "?text=" + content;
	} else {
		link = "https://web.whatsapp.com/send?phone=" + phoneNumber + "&text=" + content;
	}
	var n = window.open(link, "_blank");
	n ? n.focus() : alert("Please allow popups for this website")
}